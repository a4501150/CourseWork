#pragma once
#include<stdio.h>
#include<stdlib.h>
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include <math.h>
#include <string.h>

#include "record_mgr.h"

#define MAX_PAGES_IN_POOL   10
#define MAX_RECORD_LENGTH   1024


//struct to enable slot
typedef struct RM_TableInfo
{
	BM_BufferPool *bm; //buffer manager
	int numTuples;     //number of tuples in table
	int curPage;
	int curSlot;
	int maxSlot;
} RM_TableInfo;

RC initRecordManager(void * mgmtData)
{
	return RC_OK;
}

RC shutdownRecordManager()
{
	return RC_OK;
}

//pass by pointer to pointer to enable modify pointer inside function
RC deserializeSchemaStr(const char * schemaStr, Schema ** pSchema)
{

	const char* resultString = schemaStr;

	//Initializing related structures
	int numAttr;
	char **attrNames = (char **)malloc(sizeof(char*) * numAttr);
	DataType *dataTypes = (DataType *)malloc(sizeof(DataType) * numAttr);
	int *typeLength = (int *)malloc(sizeof(int) * numAttr);

	char *sTmp1, *sTmp2;
	sTmp1 = strtok(resultString, "<");  //"Schema with"
	sTmp2 = strtok(NULL, ">");          //Number of attributes

	numAttr = atoi(sTmp2);     //String convert to integer

	char **stringLength = calloc(numAttr, sizeof(char*));
	char **keyAttrsTmp = calloc(numAttr, sizeof(char*));

	sTmp1 = strtok(NULL, "(");       //"attributes "

	for (int i = 0; i < numAttr; i++) {
		sTmp1 = strtok(NULL, ": ");    //Attribute's name
		attrNames[i] = sTmp1;

		if (i == numAttr - 1) {
			sTmp1 = strtok(NULL, ") ");   //Data type
		}
		else {
			sTmp1 = strtok(NULL, ", ");   //Data type
		}

		stringLength[i] = (char *)calloc(strlen(sTmp1), sizeof(char));

		if (strcmp(sTmp1, "INT") == 0) {
			dataTypes[i] = DT_INT;
		}
		else if (strcmp(sTmp1, "FLOAT") == 0) {
			dataTypes[i] = DT_FLOAT;
		}
		else if (strcmp(sTmp1, "BOOL") == 0) {
			dataTypes[i] = DT_BOOL;
		}
		else {
			dataTypes[i] = DT_STRING;
			stringLength[i] = sTmp1;
		}
	}

	int keySize = 0;

	sTmp1 = strtok(NULL, "(");   //"with keys: "
	sTmp1 = strtok(NULL, ")");   //Key attributes

	if (strchr(sTmp1, ',') == NULL) { //Only one key
		keyAttrsTmp[keySize] = sTmp1;
		keySize++;
	}
	else { //More than one key

		char *keyAttribute = strtok(NULL, ", ");
		while (keyAttribute != NULL) {

			//keyAttrsTmp[keySize] = (char *)malloc(strlen(keyAttribute)*sizeof(char));
			keyAttrsTmp[keySize] = keyAttribute;
			keyAttribute = strtok(NULL, ", ");
			keySize++;
		}
	}

	//Convert the length of string.
	for (int i = 0; i < numAttr; i++) {

		if (strchr(stringLength[i], 'S') == NULL) {
			//This index does not have the length of string.
			//Move to next index.
			continue;
		}
		else {
			sTmp1 = strtok(stringLength[i], "[");   //"STRING"
			sTmp2 = strtok(NULL, "]");              //The length of string

			typeLength[i] = atoi(sTmp2);
		}
	}

	int *keyAttrs;
	keyAttrs = (int *)malloc(sizeof(int)*keySize);

	for (int i = 0; i < keySize; i++) {
		for (int j = 0; j < numAttr; j++) {
			if (strcmp(keyAttrsTmp[i], attrNames[j]) == 0) {
				keyAttrs[i] = j;
			}
		}
	}

	*pSchema = createSchema(numAttr, attrNames, dataTypes, typeLength, keySize, keyAttrs);

	return RC_OK;
}

RC createTable(char * name, Schema * schema)
{
	RC ret;

	char* data = serializeSchema(schema);

	// create file
	if ((ret = createPageFile(name) != RC_OK))
		return ret;

	//use first page to store its shit
	SM_FileHandle fileHandle;

	// openPageFile 
	if ((ret = openPageFile(name, &fileHandle)) != RC_OK)
		return ret;

	// openPageFile 
	if ((ret = ensureCapacity(1, &fileHandle) != RC_OK))
		return ret;

	// Writing the schema to first page of the page file
	if ((ret = writeBlock(0, &fileHandle, data)) != RC_OK)
		return ret;

	// Closing the file after writing
	if ((ret = closePageFile(&fileHandle)) != RC_OK)
		return ret;

	return RC_OK;

}

RC openTable(RM_TableData * rel, char * name)
{
	RC ret;

	//use first page to store its shit
	SM_FileHandle fileHandle;

	// openPageFile 
	if ((ret = openPageFile(name, &fileHandle)) != RC_OK)
		return ret;

	// read table info etc. 
	char data[PAGE_SIZE] = { 0 };
	if ((ret = readFirstBlock(&fileHandle, data)) != RC_OK)
		return ret;

	// Closing the file after writing
	if ((ret = closePageFile(&fileHandle)) != RC_OK)
		return ret;


	//INIT buffer pool
	BM_BufferPool * bm = MAKE_POOL();
	initBufferPool(bm, name, MAX_PAGES_IN_POOL, RS_LRU, NULL);

	Schema		  * sm = NULL;

	// handle out our Schema
	if ((ret = deserializeSchemaStr(data, &sm)) != RC_OK)
		return ret;

	RM_TableInfo *tbinfo = malloc(sizeof(RM_TableInfo));
	tbinfo->bm = bm;
	tbinfo->curPage = 1;
	tbinfo->curSlot = 0;
	tbinfo->maxSlot = PAGE_SIZE / MAX_RECORD_LENGTH;
	tbinfo->numTuples = 0;

	rel->name = name;
	rel->schema = sm;
	//rel->mgmtData = bm;
	rel->mgmtData = tbinfo;

	printf("[DEBUG][OpenTable]\nSchema attr 1st attr name is %s \nnumber of attrs is %d\n", rel->schema->attrNames[2], rel->schema->numAttr);

	return RC_OK;
}

RC closeTable(RM_TableData * rel)
{
	RC ret;

	RM_TableInfo *tbinfo = rel->mgmtData;

	//shutdown buffer pool, causes dirty page writen to disk
	//BM_BufferPool * bm = rel->mgmtData;
	BM_BufferPool * bm = tbinfo->bm;

	ret = shutdownBufferPool(bm);

	if (ret != RC_OK)
	{
		printf("shutdownBufferPool failed in close tabel\n");
		return ret;
	}

	//free our schema
	ret = freeSchema(rel->schema);
	if (ret != RC_OK)
	{
		printf("freeSchema failed in close tabel\n");
		return ret;
	}

	free(bm);
	free(tbinfo);

	return RC_OK;
}

RC deleteTable(char * name)
{
	return destroyPageFile(name);
}

int getNumTuples(RM_TableData * rel)
{
	RM_TableInfo *tbinfo = rel->mgmtData;
	return tbinfo->numTuples;
}

RC insertRecord(RM_TableData * rel, Record * record)
{

	RC ret;

	RM_TableInfo *tbinfo = rel->mgmtData;
	BM_BufferPool * bm = tbinfo->bm;

	//modify struct first
	if (tbinfo->curSlot == tbinfo->maxSlot - 1)
	{
		tbinfo->curSlot = 0;
		tbinfo->curPage++;
	}
	else
	{
		tbinfo->curSlot++;
	}

	record->id.page = tbinfo->curPage;
	record->id.slot = tbinfo->curSlot;

	BM_PageHandle* ph = MAKE_PAGE_HANDLE();

	ret = pinPage(bm, ph, record->id.page);
	if (ret != RC_OK)
	{
		printf("pinPage failed in insertRecord\n");
		return ret;
	}

	int slotStartPoint = MAX_RECORD_LENGTH * record->id.slot;
	memmove(ph->data + slotStartPoint, record->data, MAX_RECORD_LENGTH);

	ret = markDirty(bm, ph);
	if (ret != RC_OK)
	{
		printf("markDirty failed in insertRecord\n");
		return ret;
	}

	ret = unpinPage(bm, ph);
	if (ret != RC_OK)
	{
		printf("unpinPage failed in insertRecord\n");
		return ret;
	}

	tbinfo->numTuples++;

	//printf("insert record done, curPage %d, curSlot %d, maxslot %d\n", record->id.page, record->id.slot, tbinfo->maxSlot);

	return RC_OK;
}

RC deleteRecord(RM_TableData * rel, RID id)
{
	//simple delete, leave delete record's disk space unused. this can improve but too fuck complex

	RM_TableInfo *tbinfo = rel->mgmtData;
	BM_BufferPool * bm = tbinfo->bm;


	BM_PageHandle* ph = MAKE_PAGE_HANDLE();
	pinPage(bm, ph, id.page);

	char tmp[MAX_RECORD_LENGTH] = { 0 };
	int slotStartPoint = MAX_RECORD_LENGTH * id.slot;

	memcpy(ph->data + slotStartPoint, tmp, MAX_RECORD_LENGTH); // simply make that page empty

	markDirty(bm, ph);
	unpinPage(bm, ph);

	tbinfo->numTuples--;

	return RC_OK;
}

RC updateRecord(RM_TableData * rel, Record * record)
{
	return RC_OK;
}

RC getRecord(RM_TableData * rel, RID id, Record * record)
{
	RC ret;

	RM_TableInfo *tbinfo = rel->mgmtData;
	BM_BufferPool * bm = tbinfo->bm;

	int slotStartPoint = MAX_RECORD_LENGTH * id.slot;

	BM_PageHandle* ph = MAKE_PAGE_HANDLE();
	ret = pinPage(bm, ph, id.page);
	if (ret != RC_OK)
	{
		printf("pinPage failed in getRecord\n");
		return ret;
	}

	ret = createRecord(&record, rel->schema);
	if (ret != RC_OK)
	{
		printf("createRecord failed in getRecord\n");
		return ret;
	}

	ret = markDirty(bm, ph); //not sure if it is required here
	if (ret != RC_OK)
	{
		printf("markDirty failed in getRecord\n");
		return ret;
	}


	memmove(record->data, ph->data + slotStartPoint, MAX_RECORD_LENGTH);

	ret = unpinPage(bm, ph);
	if (ret != RC_OK)
	{
		printf("unpinPage failed in getRecord\n");
		return ret;
	}

	record->id = id;

	return RC_OK;
}

RC startScan(RM_TableData * rel, RM_ScanHandle * scan, Expr * cond)
{
	return RC_OK;
}

RC next(RM_ScanHandle * scan, Record * record)
{
	return RC_OK;
}

RC closeScan(RM_ScanHandle * scan)
{
	return RC_OK;
}

int getRecordSize(Schema * schema)
{
	return 0;
}

Schema * createSchema(int numAttr, char ** attrNames, DataType * dataTypes, int * typeLength, int keySize, int * keys)
{
	Schema * schema = (Schema*)malloc(sizeof(Schema));

	schema->numAttr = numAttr;
	schema->attrNames = attrNames;
	schema->dataTypes = dataTypes;
	schema->typeLength = typeLength;
	schema->keySize = keySize;
	schema->keyAttrs = keys;

	return schema;

}

RC freeSchema(Schema * schema)
{

	free(schema->dataTypes);
	free(schema->keyAttrs);
	free(schema->typeLength);

	for (int i = 0; i++; i < schema->numAttr)
		free(schema->attrNames[i]);

	free(schema->attrNames);
	free(schema);

	return RC_OK;
}

RC createRecord(Record ** record, Schema * schema)
{
	*record = calloc(1, sizeof(Record));
	(*record)->data = calloc(1, MAX_RECORD_LENGTH);

	return RC_OK;
}

RC freeRecord(Record * record)
{
	free(record->data);
	free(record);
	return RC_OK;
}

RC getAttr(Record * record, Schema * schema, int attrNum, Value ** value)
{
	if (attrNum >= schema->numAttr)
	{
		printf("out of bound attr num\n");
		return RC_RM_ATTRNUM_OUTOFBOUND;
	}
	int firstSlimPointPosition = MAX_RECORD_LENGTH / schema->numAttr; //first slim point postion
															  
	char* tmp = malloc(firstSlimPointPosition+1);//additional 1 for datatype.


	//handle out our serlized value
	memmove(tmp+1, record->data + attrNum * (firstSlimPointPosition), firstSlimPointPosition);

	//append datatype char
	switch (schema->dataTypes[attrNum])
	{
	case DT_STRING:
		//memmove(tmp, 's', 1);
		tmp[0] = 's';
		break;
	case DT_INT:
		//memmove(tmp, 'i', 1);
		tmp[0] = 'i';
		break;
	case DT_FLOAT:
		//memmove(tmp, 'f', 1);
		tmp[0] = 'f';
		break;
	case DT_BOOL:
		//memmove(tmp, 'b', 1);
		tmp[0] = 'b';
		break;
	}

	//make it back to value
	(*value) = stringToValue(tmp);

	printf("datatype is %d string is %s\n", (*value)->dt, tmp + 1);

	//clean 
	free(tmp);

	return RC_OK;

}

RC setAttr(Record * record, Schema * schema, int attrNum, Value * value)
{
	if (attrNum >= schema->numAttr)
	{
		printf("out of bound attr num\n");
		return RC_RM_ATTRNUM_OUTOFBOUND;
	}

	int firstSlimPointPosition = MAX_RECORD_LENGTH / schema->numAttr; //first slim point postion
	char *serializedValue = serializeValue(value);

	memmove(record->data + attrNum * (firstSlimPointPosition), serializedValue, firstSlimPointPosition); //copy value to that part in data field
	free(serializedValue);

	return RC_OK;
}