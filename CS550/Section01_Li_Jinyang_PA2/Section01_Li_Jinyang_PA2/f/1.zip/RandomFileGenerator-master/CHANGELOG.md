# Changelog

## 18.11.2016

Markus B. introduced a cooler way of handling with the enum values using getter/private constructor within the enum class
