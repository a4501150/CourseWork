select 'drop table '||table_name||' cascade constraints;'from user_tables;


drop table SCREENROOM cascade constraints;
drop table MOVIETYPE cascade constraints;
drop table TYPE_IN cascade constraints;
drop table REVIEW cascade constraints;
drop table MEMBER cascade constraints;
drop table REGULARMEMBER cascade constraints;
drop table ORDERS cascade constraints;
drop table THREAD cascade constraints;
drop table STAFF cascade constraints;
drop table MANAGER cascade constraints;
drop table STAFFTYPE cascade constraints;
drop table SCHEDULE cascade constraints;
drop table STATUS_POINTS_RATE cascade constraints;
drop table MOVIEUPDATE cascade constraints;
drop table ALERTS cascade constraints;