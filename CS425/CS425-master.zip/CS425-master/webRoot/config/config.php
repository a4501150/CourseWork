<?php

define("DB_HOST", "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = fourier.cs.iit.edu)(PORT = 1521)) (CONNECT_DATA =(SID = ORCL)))");

define("DB_USER", "bsong11");
define("DB_PASS", "930107");

?>