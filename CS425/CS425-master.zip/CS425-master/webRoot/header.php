﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
	
	<link rel="stylesheet" type="text/css" href="styles/styles.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="styles/css/slide.css" media="screen" />
	
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
       
    <script src="styles/js/slide.js" type="text/javascript"></script>
	
    <title>Online Ticketing Management & Sales System </title>

</head>
<body>



