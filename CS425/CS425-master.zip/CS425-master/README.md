# CS425
ILLINOIS INSTITUTE OF TECHNOLOGY IIT database organization CS425 Final Project Online Cinema Ticket 


CS425 of fall2015 final project
illinois institute of technology (iit || IIT)

This project is written by notepad++ under windows server 2008.

#Requirements

General PHP Runtime Environment like XAMPP.
Oracle Instant Client from oracle website. (Ver.11g used in project)
Oracle database (which is already set-up in FOURIRE.CS.IIT.EDU).

#Build

No build is necessary for php.
For Oracle Instant Client you must modify the server path to include the Oracle instant Client folder path.
However, 
the triggers and database schema SQL script files (*.SQL located in SQL_Scripts folder) needs to be manually run in SQL developer in orders.

create.SQL -> insert.SQL -> triggers.SQL

#Execute

Just Put the root path in your webROOT and launch.


#Clean up

deleteDBTS.SQL

