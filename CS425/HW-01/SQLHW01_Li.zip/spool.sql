PHONE                FAMILYNAME         
-------------------- --------------------
312-555-9403         O’Shea              


F_NAME               L_NAME             
-------------------- --------------------
Leslie               Blackburn           


FIRST_NAME           LAST_NAME          
-------------------- --------------------
Annie                Heard               
James                Robertson           


FIRST_NAME           LAST_NAME          
-------------------- --------------------
Abby                 Smith               
Harry                Tang                


FIRST_NAME           LAST_NAME          
-------------------- --------------------
Abby                 Smith               
Mike                 O’Shea              
April                O’Shea              
Harry                Tang                
DongMei              Tang                
Laura                Dickinson           
Emily                Citrin              
Maria                Garcia              

 8 rows selected 

FIRST_NAME           LAST_NAME          
-------------------- --------------------
Mike                 O’Shea              
April                O’Shea              
Harry                Smith               
Lisa                 Brown               


TYPE
--------------------
DESCRIPTION
--------------------------------------------------------------------------------
Art                  
Paining, Sculpting, ect                                                         

Kids                 
Courses geared towards children 13 and younger                                  

Languages            
Anything to do with writing, literature, or communication                       


TYPE
--------------------
DESCRIPTION
--------------------------------------------------------------------------------
Craft                
Knitting, sewing, ect                                                           

Exercise             
Any courses having to do with physical activity                                 


